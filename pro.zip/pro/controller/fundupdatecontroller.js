var connection = require('C:\\Users\\hp\\Desktop\\pro\\config');
module.exports=function(req,res)
{
    connection.query("update fund set amt=amt-'"+req.body.amount+"'",function(err,results)
    {
        res.redirect('/administrator/financial');
    
    });
    }