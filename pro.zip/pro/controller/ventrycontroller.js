var connection = require('C:\\Users\\hp\\Desktop\\pro\\config');
module.exports=function(req,res){
    console.log(req.body);
    var users={
        "firm_name":req.body.firmname,
        "address":req.body.address,
        "city":req.body.city,
        "pin":req.body.pincode,
        "contact":req.body.contact
    }  
    var iid,vid;
    
            connection.query("insert into vendors (firm_name,address,city,pin, contact) values ('"+users.firm_name+"', '"+users.address+"', '"+users.city+"', '"+users.pin+"', '"+users.contact+"')",function (error, results) {
                if(error){
                    console.log(error);
                }
                else{
                    // console.log(results);
                    // req.flash('indentsuc','Indent submitted successfully');
                    res.redirect('/administrator');
                }
            });
}