var connection = require('C:\\Users\\hp\\Desktop\\pro\\config');

module.exports = function(req,res){
    connection.query('select item_id,item_name from item_list', function (error, dropdownVals, fields){
    //    console.log(dropdownVals);
        res.render('indent',{
            dd: dropdownVals,
            name: req.session.name
        });
    });
}