module.exports = function(req,res){
    res.render('home',{
        mismatch: req.flash('mismatch')[0],
        notify: req.flash('notify')[0],
        exists: req.flash('exists')[0],
        wrong: req.flash('wrong')[0]
    });
}