var connection = require('C:\\Users\\hp\\Desktop\\pro\\config');

module.exports = function(req,res){
    connection.query('update indent set flag="1" where indent_no= ?',[req.params.id], function(error, result){      
        connection.query('update indent set eamt="'+req.body.eamt+'" where indent_no= ?',[req.params.id], function(err,re){
            // connection.query('SELECT indent_no,name,item_name,specification,purpose,quantity,eamt,flag FROM indent INNER JOIN users ON indent.indenter_id=users.user_id where indent_no= ?',[req.params.id],function(error,result1){
            //     res.render('pending',{
            //         name: req.session.name,
            //         st:result1
            //     });
            // });
            res.redirect('/administrator/pending');
        }); 
    });
}