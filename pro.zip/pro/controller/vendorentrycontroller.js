var connection = require('C:\\Users\\hp\\Desktop\\pro\\config');

module.exports = function(req,res){
    res.render('vendorentry',{
        name : req.session.name
    });
}