var connection = require('C:\\Users\\hp\\Desktop\\pro\\config');

module.exports = function(req,res){
    connection.query('select * from received_quotation where indent_no= ?',[req.params.id], function (error, dropdownVals, fields){
        connection.query('select i.item_name from indent as i INNER join received_quotation as r on r.indent_no=i.indent_no ', function(err,dropdown){
        connection.query('select r.firm_name,r.total_rate,v.address,v.city from vendors as v INNER join received_quotation as r on r.firm_name=v.firm_name WHERE r.indent_no="'+req.params.id+'" order by total_rate desc limit 1', function(err,min){
                res.render('comparativetableform',{
                st: dropdownVals,
                dd: dropdown,
                d:min,
                name: req.session.name
                });
            });
        });
    });
}