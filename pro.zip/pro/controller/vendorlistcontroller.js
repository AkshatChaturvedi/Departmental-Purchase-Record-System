var connection = require('C:\\Users\\hp\\Desktop\\pro\\config');

module.exports = function(req,res){
    connection.query('select * from vendors',function(err,results,field){
        // console.log(results);
            res.render('vendorlist',{
                name: req.session.name,
                st:results
            });
    });
}