var connection = require('C:\\Users\\hp\\Desktop\\pro\\config');
module.exports.register=function(req,res){
    var users={
        "name":req.body.name,
        "email":req.body.email,
        "password":req.body.password,
        "pos":req.body.pos
    }
    var pwd = req.body.password;
    var cpwd = req.body.confirmpassword;
    // console.log(req.body);
    connection.query('SELECT * FROM users WHERE email= ?',[users.email], function(error,result){
        if(result.length>0){
            req.flash('exists','email already exist');
            res.redirect('/');
        }
        else{
            if(pwd===cpwd){
                connection.query('INSERT INTO users SET ?',users, function (error, results) {
                    if(error){
                        console.log(error);
                    }
                    else{
                        // console.log(results);
                        res.redirect('/');
                    }
                });
            }
            else{
                req.flash('wrong','passwords do not match');
                res.redirect('/');
            }
        }
    });
}