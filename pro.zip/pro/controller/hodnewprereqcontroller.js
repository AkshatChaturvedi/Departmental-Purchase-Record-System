var connection = require('C:\\Users\\hp\\Desktop\\pro\\config');

module.exports = function(req,res){
    connection.query('update indent set status="2" where indent_no= ?',[req.params.id], function(error, result){       
        res.redirect('/hod/previous');
                    });
}