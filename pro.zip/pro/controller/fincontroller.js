var connection = require('C:\\Users\\hp\\Desktop\\pro\\config');
module.exports=function(req,res)
{
    connection.query("select * from fund",function(err,results)
    {
        res.render('fund',{
            name:req.session.name,
            c:results
        });
    
    })
    }