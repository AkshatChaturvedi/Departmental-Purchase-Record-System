var connection = require('C:\\Users\\hp\\Desktop\\pro\\config');

module.exports = function(req,res){
    connection.query('update indent set flag="2" where indent_no= ?',[req.params.id], function(error, result){       
        connection.query('select item_id,indenter_id,quantity,specification from indent where indent_no= ?',[req.params.id], function(err,result1){
            connection.query('update stock set available_quantity=available_quantity -"'+result1[0].quantity+'" where item_id="'+result1[0].item_id+'" and specification="'+result1[0].specification+'" ', function(err, result2){
                connection.query('select DATE_FORMAT(CURRENT_DATE(),"%y-%m-%d") as date', function(err,fs){
                    connection.query("insert into indented_item (indenter_id,item_id,indent_no,indented_quantity,date_of_issue) values ('"+result1[0].indenter_id+"', '"+result1[0].item_id+"', '"+req.params.id+"', '"+result1[0].quantity+"', '"+fs[0].date+"')", function(err,resu){
                        res.redirect('/administrator/previous');
                    });
                });
            });
        });
    });
}