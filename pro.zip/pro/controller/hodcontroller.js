module.exports = function(req,res){
    res.render('hod',{
        name:req.session.name
    });
}