var connection = require('C:\\Users\\hp\\Desktop\\pro\\config');

module.exports = function(req,res){
    // connection.query('select * from stock',function(err,results,field){
    //     console.log(results);
    //         res.render('stocktable',{
    //             name: req.session.name,
    //             st:results
    //         });
    // });
    connection.query('SELECT item_id,item_name,specification,available_quantity,received_quantity,firm_name FROM stock INNER JOIN vendors ON stock.vendor_id=vendors.id', function(error,result){
        res.render('stocktable',{
             name: req.session.name,
             st:result
        });
    });
}