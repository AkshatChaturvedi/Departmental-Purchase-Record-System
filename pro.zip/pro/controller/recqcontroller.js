var connection = require('C:\\Users\\hp\\Desktop\\pro\\config');
module.exports=function(req,res){
    console.log(req.body);
    var users={
        "indent_no":req.body.indent_no,
        "firm_name":req.body.firm_name,
        "quantity":req.body.quantity,
        "unit_rate":req.body.unit_rate,
        "total_rate":req.body.total_rate,
        "terms":req.body.terms,
        "ref":req.body.ref,
        "date":req.body.date
    }  
    connection.query("insert into received_quotation (indent_no,firm_name,quantity,unit_rate,total_rate, terms,ref,date) values ('"+users.indent_no+"', '"+users.firm_name+"', '"+users.quantity+"', '"+users.unit_rate+"', '"+users.total_rate+"', '"+users.terms+"', '"+users.ref+"', '"+users.date+"')",function (error, results) {
        if(error){
            console.log(error);
        }
        else{
            // console.log(results);
            // req.flash('indentsuc','Indent submitted successfully');
            res.redirect('/administrator');
        }
    });
}