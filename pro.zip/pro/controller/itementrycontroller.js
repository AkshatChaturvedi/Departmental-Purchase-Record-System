var connection = require('C:\\Users\\hp\\Desktop\\pro\\config');

module.exports = function(req,res){
    connection.query('select item_name from item_list', function (error, dropdownVals, fields){
        connection.query('select firm_name from vendors', function (error, dropdown, fields){
            res.render('itementry',{
                dd: dropdownVals,
                vv: dropdown,
                name: req.session.name
            });
        });
    });
}