var connection = require('C:\\Users\\hp\\Desktop\\pro\\config');

module.exports = function(req,res){
   connection.query('SELECT indent_no,name,item_name,specification,quantity,eamt,flag FROM indent INNER JOIN users ON indent.indenter_id=users.user_id where name="'+req.params.name+'" and flag="1" ', function(err, result){
        connection.query('select * from vendors', function(err,field){
            var totalamt=0;
            for(var i=0; i<result.length; i++){
            totalamt+=Number(result[i].eamt);
            }
            res.render('custompending',{
            name: req.session.name,
            st:result,
            totalamt: totalamt,
            dd:field
            });
        });
   });
}