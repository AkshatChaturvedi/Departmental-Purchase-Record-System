var connection = require('C:\\Users\\hp\\Desktop\\pro\\config');

module.exports = function(req,res){
    connection.query('select distinct r.indent_no, i.item_name, u.name, flag from received_quotation as r INNER join indent as i on r.indent_no=i.indent_no INNER JOIN users as u on u.user_id=i.indenter_id and flag="1"', function (error, dropdownVals, fields){
        res.render('comparativetable',{
            st: dropdownVals,
            name: req.session.name
        });
    });
}