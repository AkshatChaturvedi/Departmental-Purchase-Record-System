var connection = require('C:\\Users\\hp\\Desktop\\pro\\config');

module.exports = function(req,res){
    connection.query('SELECT indent_no,name,item_name,specification,purpose,quantity,flag,status FROM indent INNER JOIN users ON indent.indenter_id=users.user_id where flag="-1"', function(error,result){
        res.render('adreview',{
             name: req.session.name,
             st:result
        });
    });
}