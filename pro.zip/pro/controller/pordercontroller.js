var connection = require('C:\\Users\\hp\\Desktop\\pro\\config');

module.exports = function(req,res){
   connection.query('select * from received_quotation where indent_no="'+req.body.indent_no+'" and firm_name="'+req.body.firm_name+'"',function(err,results){
    connection.query('select * from vendors where firm_name=?',[req.body.firm_name],function(err,result){
        res.render('purchaseorderform',{
        st:results,
        item_name:req.body.item_name,
        date:req.body.date,
        dd: result
         });
    });
   });
   // console.log(req.body);
}