var connection = require('C:\\Users\\hp\\Desktop\\pro\\config');
module.exports.authenticate=function(req,res){
    var email=req.body.email;
    var password=req.body.password;
    connection.query('SELECT * FROM users WHERE email = ?',[email], function (error, results, fields) {
      if (error) {
          // res.json({
          //   status:false,
          //   message:'there are some error with query'
          //   })
          console.log('error');
      }else{
        if(results.length >0){
            if(password==results[0].password){
                  req.session.email = email;
                  req.session.name= results[0].name;
                  if(results[0].pos=='Hod')
                  res.redirect('/hod');
                  else if(results[0].pos=='Indenter')
                  res.redirect('/indenter');
                  else if(results[0].pos=='Administrator')
                  res.redirect('/administrator');
            }else{
                console.log('Password not matched');
                req.flash('mismatch', 'password incorrect');
                res.redirect('/');
            }
        }
        else{
          req.flash('notify', 'User not existing');
          res.redirect('/');
        }
      }
    });
}