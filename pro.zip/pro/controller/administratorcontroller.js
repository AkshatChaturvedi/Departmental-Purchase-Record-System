module.exports = function(req,res){
    res.render('ad',{
        name:req.session.name
    });
}