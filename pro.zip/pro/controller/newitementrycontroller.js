var connection = require('C:\\Users\\hp\\Desktop\\pro\\config');
module.exports=function(req,res){
    console.log(req.body);
    var users={
        "item_name":req.body.item_name,
        "firm_name":req.body.firm_name,
        "specification":req.body.specification,
        "receivedquantity":req.body.receivedquantity
    }   
    var iid,vid;
    connection.query('SELECT item_id FROM item_list WHERE item_name=?',[users.item_name], function(error,result){
        iid=result[0].item_id;
        connection.query('SELECT id FROM vendors WHERE firm_name=?',[users.firm_name], function(error,result){
            vid=result[0].id;
            connection.query('select * from stock where item_name="'+req.body.item_name+'" and specification="'+req.body.specification+'" and vendor_id="'+vid+'"', function(err,field){
                if(field.length>0){
                    connection.query('update stock set available_quantity=available_quantity+"'+req.body.receivedquantity+'",received_quantity=received_quantity+"'+req.body.receivedquantity+'" where item_name="'+req.body.item_name+'" and specification="'+req.body.specification+'" and vendor_id="'+vid+'"', function(err,array){
                        res.redirect('/administrator');
                    });
                }
                else{
                    connection.query("insert into stock (item_id,item_name,specification,available_quantity, received_quantity, vendor_id) values ('"+iid+"', '"+req.body.item_name+"', '"+req.body.specification+"', '"+req.body.receivedquantity+"', '"+req.body.receivedquantity+"', '"+vid+"')",function (error, results) {
                        res.redirect('/administrator');
                    });
                }
            });
        });

    });
}