var connection = require('C:\\Users\\hp\\Desktop\\pro\\config');

module.exports = function(req,res){
    connection.query('select firm_name from vendors', function (error, dropdownVals, fields){
        res.render('receivedquotation',{
            dd: dropdownVals,
            name: req.session.name
        });
    });
}