var connection = require('C:\\Users\\hp\\Desktop\\pro\\config');
module.exports.register=function(req,res){
    // console.log(req.body);
    var users={
        "item_name":req.body.item_name,
        "specification":req.body.specification,
        "purpose":req.body.purpose,
        "quantity":req.body.quantity
    }  
    if(req.body.item_name=="-----")
    {
        users.item_name=req.body.item_name1;
        connection.query('insert into item_list (item_name) values ("'+req.body.item_name1+'")',function(error,re)
        {
            console.log(req.body.item_name1);
        });
    }
    console.log(users);
    var uid;
    var iid;
    connection.query('SELECT user_id FROM users WHERE email=?',[req.session.email], function(error,result){
        uid=result[0].user_id;
        connection.query('SELECT item_id FROM item_list WHERE item_name=?',[users.item_name], function(error,result){
            iid=result[0].item_id;
            connection.query('select DATE_FORMAT(CURRENT_DATE(),"%y-%m-%d") as date',function(err,field){
                connection.query("insert into indent (indenter_id,item_id,item_name,specification,purpose,quantity,date) values ('"+uid+"', '"+iid+"', '"+users.item_name+"', '"+req.body.specification+"', '"+req.body.purpose+"', '"+req.body.quantity+"', '"+field[0].date+"')",function (error, results) {
                    if(error){
                        console.log(error);
                    }
                    else{
                        // console.log(field);
                        // req.flash('indentsuc','Indent submitted successfully');
                        res.redirect('/indenter');
                    }
                });
            });
        });

    });
}