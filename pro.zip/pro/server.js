var express=require("express");
var bodyParser=require('body-parser');
var session = require('express-session');
// var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var flash=require('connect-flash');

var app = express();

app.set('view engine', 'ejs');


var homepagecontroller=require('./controller/homepagecontroller');
var logincontroller=require('./controller/logincontroller');
var registercontroller=require('./controller/registercontroller');

var hodcontroller=require('./controller/hodcontroller');

var indentercontroller=require('./controller/indentercontroller');

var administratorcontroller=require('./controller/administratorcontroller');

var newindentcontroller=require('./controller/newindentcontroller');
var itementrycontroller=require('./controller/itementrycontroller.js');
var newitementrycontroller=require('./controller/newitementrycontroller.js');
var stockcontroller=require('./controller/stockcontroller.js');
var vendorlistcontroller=require('./controller/vendorlistcontroller.js');
var newreqcontroller=require('./controller/newreqcontroller.js');
var prevreqcontroller=require('./controller/prevreqcontroller');
var newprevreqcontroller=require('./controller/newprevreqcontroller');
var pendingcontroller=require('./controller/pendingcontroller');
var newpendingcontroller=require('./controller/newpendingcontroller');
var qcontroller=require('./controller/qcontroller');
var quotationcontroller=require('./controller/quotationcontroller');
var ventrycontroller=require('./controller/ventrycontroller');
var vendorentrycontroller=require('./controller/vendorentrycontroller');
var rqcontroller=require('./controller/rqcontroller');
var recqcontroller=require('./controller/recqcontroller');
var logoutcontroller=require('./controller/logoutcontroller');
var ctablecontroller=require('./controller/ctablecontroller');
var tcontroller=require('./controller/tcontroller');
var purchasecontroller=require('./controller/purchasecontroller');
var pordercontroller=require('./controller/pordercontroller');
var issuependingcontroller=require('./controller/issuependingcontroller');
var hodnewreqcontroller=require('./controller/hodnewreqcontroller');
var hodprereqcontroller=require('./controller/hodprereqcontroller');
var hodnewprereqcontroller=require('./controller/hodnewprereqcontroller');
var hodreviewcontroller=require('./controller/hodreviewcontroller');
var adminreviewcontroller=require('./controller/adminreviewcontroller');
var indentreviewcontroller=require('./controller/indentreviewcontroller');
var fincontroller=require('./controller/fincontroller');
var fundupdatecontroller=require('./controller/fundupdatecontroller');

var auth=require('./middleware/auth');

app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());
app.use('/public',express.static('public'));
//app.use(cookieParser('secretString'));
app.use(session({secret:'secret' ,cookie: { maxAge: 600000 }}));
app.use(flash());

/* route to handle login and registration */
app.get('/', homepagecontroller);
app.get('/hod', auth, hodnewreqcontroller);
app.get('/hod/previous', auth, hodprereqcontroller);
app.get('/hod/approve/:id',auth, hodnewprereqcontroller);
app.get('/hod/review/:id',auth, hodreviewcontroller);
app.get('/indenter', auth, indentercontroller);
app.get('/indenter/review', auth, indentreviewcontroller);
app.get('/administrator', auth, newreqcontroller);
app.get('/administrator/itementry',auth, itementrycontroller);
app.get('/administrator/stock',auth, stockcontroller);
//app.get('/administrator/newreq', newreqcontroller);
app.get('/administrator/vendorlist',auth, vendorlistcontroller);
app.get('/administrator/issueitem/:id',auth, prevreqcontroller);
app.get('/administrator/previous',auth, newprevreqcontroller);
app.get('/administrator/issuependingitem/:id', auth,issuependingcontroller);
app.get('/administrator/vendorentry',auth,vendorentrycontroller);
app.get('/administrator/receivedquotation',auth, rqcontroller);
app.get('/administrator/comparativetable',auth, ctablecontroller);
app.get('/administrator/pending/:name',auth, qcontroller);
app.get('/administrator/review',auth, adminreviewcontroller);
app.get('/administrator/pending/', auth,newpendingcontroller);
app.get('/administrator/purchaseorder/:id',auth,purchasecontroller);
app.get('/administrator/table/:id',auth, tcontroller);
app.get('/administrator/financial',auth,fincontroller);
app.post('/administrator/fund/tmp',fundupdatecontroller);

app.get('/logout', logoutcontroller);


app.post('/administrator/createquotation/:name',auth, quotationcontroller);
app.post('/administrator/storeentry',auth,newitementrycontroller);
app.post('/administrator/purchaseorder',auth,pordercontroller);
app.post('/user/register',registercontroller.register);
app.post('/user/login',logincontroller.authenticate);
app.post('/user/indenter',auth,newindentcontroller.register);
app.post('/administrator/ventry',auth,ventrycontroller);
app.post('/administrator/pending/:id',auth, pendingcontroller);
app.post('/administrator/recquotation',auth, recqcontroller);

app.listen(8010);
console.log('listening on port 8010');
